/*
 * 메인 첫 화면 (2026-10-15 리뉴얼, 2026-10-16 수정)
 * - 햇살(빛줄기)과 떠다니는 빛 입자를 캔버스에 그림
 * - PC: 마우스가 화면 왼쪽 끝 30% 안으로 오면 스킨케어, 오른쪽 끝 30% 안으로 오면 이너 웰니스가 펼쳐짐(누르면 해당 페이지)
 *        화면 아래쪽 가운데로 오면 About us가 커짐(누르면 회사 소개 페이지)
 * - 휴대폰·태블릿은 아래쪽 타일과 About us 버튼을 누르면 이동 (CSS가 처리)
 * - '움직임 줄이기' 설정이면 정지된 한 장면만 그림
 */
(function () {
  var intro = document.getElementById("intro");
  if (!intro) return;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var desk = window.matchMedia("(min-width: 900px) and (hover: hover) and (pointer: fine)");

  var EDGE = 0.30;      // 좌우가 반응하는 범위(화면 폭 대비). 2026-10-16 0.38 → 0.30 (약 20% 줄임)
  var BOTTOM = 0.76;    // 이 높이보다 아래 + 가운데(EDGE ~ 1-EDGE)면 About us 확대
  var READY_MS = 4200;  // 등장 애니메이션이 끝난 뒤부터 반응

  // ---------------------------------------------------------------- left / right lines, About us at the bottom
  var state = "", ready = reduce;
  if (!reduce) setTimeout(function () { ready = true; }, READY_MS);
  function setState(s) {
    if (s === state) return;
    state = s;
    intro.setAttribute("data-state", s);
    if (reduce && ctx) { pk = (s === "l" || s === "r") ? 1 : 0; draw(t0); }
  }
  intro.addEventListener("mousemove", function (e) {
    var r = intro.getBoundingClientRect();
    mx = (e.clientX - r.left) / r.width;
    my = (e.clientY - r.top) / r.height;
    if (!ready || !desk.matches) return;
    if (my > BOTTOM && mx > EDGE && mx < 1 - EDGE) return setState("b");
    var s = state === "b" ? "" : state;
    // Hysteresis: an open side stays open until the pointer reaches the other side's edge area
    if (s === "l") { if (mx > 1 - EDGE) s = "r"; }
    else if (s === "r") { if (mx < EDGE) s = "l"; }
    else if (mx < EDGE) s = "l";
    else if (mx > 1 - EDGE) s = "r";
    setState(s);
  });
  intro.addEventListener("mouseleave", function () { setState(""); mx = 0.5; my = 0.4; });
  intro.querySelectorAll(".side, .intro-about").forEach(function (a) {
    a.addEventListener("focus", function () { if (desk.matches) setState(a.getAttribute("data-side")); });
    a.addEventListener("blur", function () { setState(""); });
  });
  desk.addEventListener && desk.addEventListener("change", function () { setState(""); });
  window.addEventListener("pageshow", function (e) { if (e.persisted) setState(""); });

  // ---------------------------------------------------------------- light rays + floating particles
  var cv = intro.querySelector(".intro-fx");
  var ctx = cv && cv.getContext && cv.getContext("2d");
  var leaves = [].slice.call(intro.querySelectorAll(".lf"));
  var depth = [0.35, 1, 0.7, 0.85];
  // When a side opens, the foreground branches part toward their corners so the content and the logo stay clear
  var part = [[0, 0], [-170, -130], [110, -90], [80, 90]], pk = 0;
  var W = 0, H = 0, parts = [], rays = [], mx = 0.5, my = 0.4, sx = 0.5, sy = 0.4, t0 = 0, raf = 0, running = false;
  if (!ctx) return;

  function rnd(a, b) { return a + Math.random() * (b - a); }
  function resize() {
    var w = intro.clientWidth, h = intro.clientHeight;
    var dpr = Math.max(1, Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(4e6 / (w * h))));
    if (parts.length && Math.round(w * dpr) === cv.width && Math.round(h * dpr) === cv.height) return;
    W = w; H = h;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = W < 700 ? 34 : 72;
    parts = [];
    for (var i = 0; i < n; i++) {
      parts.push({ x: rnd(0, W), y: rnd(0, H), r: rnd(0.6, 2.4), z: rnd(0.3, 1), s: rnd(0.07, 0.25), p: rnd(0, 6.28), a: rnd(0.3, 0.85) });
    }
    rays = [];
    for (var k = 0; k < 7; k++) {
      rays.push({ a: 0.40 + k * 0.12 + rnd(-0.04, 0.04), w: rnd(0.035, 0.09), al: rnd(0.20, 0.38), sp: rnd(0.07, 0.2), ph: rnd(0, 6.28) });
    }
    if (!running) draw(performance.now());
  }

  function draw(now) {
    if (!t0) t0 = now;
    var t = (now - t0) / 1000;
    var fade = reduce ? 1 : Math.min(1, t / 4);
    sx += (mx - sx) * 0.03; sy += (my - sy) * 0.03;
    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = "lighter";

    // Sun just above the top-left; it leans a little toward the pointer
    var ox = W * (0.16 + (sx - 0.5) * 0.08), oy = -H * 0.14, len = Math.hypot(W, H) * 1.25;
    for (var i = 0; i < rays.length; i++) {
      var ry = rays[i];
      var ang = ry.a + Math.sin(t * ry.sp + ry.ph) * 0.025 + (sx - 0.5) * 0.06;
      var al = ry.al * (0.65 + 0.35 * Math.sin(t * ry.sp * 1.7 + ry.ph)) * fade;
      var a1 = ang - ry.w / 2, a2 = ang + ry.w / 2;
      var g = ctx.createLinearGradient(ox, oy, ox + Math.cos(ang) * len, oy + Math.sin(ang) * len);
      g.addColorStop(0, "rgba(255,238,178," + al + ")");
      g.addColorStop(0.5, "rgba(255,246,206," + al * 0.5 + ")");
      g.addColorStop(1, "rgba(255,252,232,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(ox, oy);
      ctx.lineTo(ox + Math.cos(a1) * len, oy + Math.sin(a1) * len);
      ctx.lineTo(ox + Math.cos(a2) * len, oy + Math.sin(a2) * len);
      ctx.closePath();
      ctx.fill();
    }

    for (var j = 0; j < parts.length; j++) {
      var p = parts[j];
      if (!reduce) {
        p.y -= p.s * p.z;
        p.x += Math.sin(t * 0.3 + p.p) * 0.12 * p.z;
        if (p.y < -12) { p.y = H + 12; p.x = rnd(0, W); }
      }
      var px = p.x - (sx - 0.5) * 34 * p.z, py = p.y - (sy - 0.5) * 22 * p.z;
      var tw = 0.55 + 0.45 * Math.sin(t * 0.8 + p.p);
      var alpha = p.a * tw * fade;
      ctx.fillStyle = "rgba(255,252,232," + alpha * 0.35 + ")";
      ctx.beginPath(); ctx.arc(px, py, p.r * 3.2, 0, 6.2832); ctx.fill();
      ctx.fillStyle = "rgba(255,255,246," + alpha + ")";
      ctx.beginPath(); ctx.arc(px, py, p.r, 0, 6.2832); ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";

    // Leaves drift slightly against the pointer for depth, and part when a side opens
    if (!reduce) pk += (((state === "l" || state === "r") ? 1 : 0) - pk) * 0.035;
    for (var k = 0; k < leaves.length; k++) {
      var d = depth[k] || 0.6, o = part[k] || [0, 0];
      leaves[k].style.translate = (-(sx - 0.5) * 30 * d + o[0] * pk).toFixed(1) + "px " + (-(sy - 0.5) * 18 * d + o[1] * pk).toFixed(1) + "px";
    }
    if (running) raf = requestAnimationFrame(draw);
  }

  function start() { if (running || reduce) return; running = true; raf = requestAnimationFrame(draw); }
  function stop() { running = false; cancelAnimationFrame(raf); }

  resize();
  window.addEventListener("resize", function () { clearTimeout(resize.t); resize.t = setTimeout(resize, 150); });
  if ("IntersectionObserver" in window) {
    new IntersectionObserver(function (es) { es[es.length - 1].isIntersecting && !document.hidden ? start() : stop(); }).observe(intro);
  } else start();
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) stop();
    else if (intro.getBoundingClientRect().bottom > 0) start();
  });
})();
