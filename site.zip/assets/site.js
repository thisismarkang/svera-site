/*
 * 판매처 주소 설정
 * 비워 두면 "구매하기"·"선물하기" 버튼은 사이트의 주문서(/order/)로 이동합니다.
 * 스마트스토어 등 판매처가 열리면 아래 따옴표 안에 상품 주소를 넣으면,
 * 모든 언어의 구매 버튼이 주문서 대신 그 주소로 연결됩니다.
 * 예) var STORE_URL = "https://smartstore.naver.com/svera/products/1234567890";
 */
var STORE_URL = "https://sbera001.cafe24.com/product/detail.html?product_no=11";

(function () {
  // With a store set, the old order sheet (/order/, /en/order/ …) forwards to the store
  if (STORE_URL && /\/order\/?$/.test(location.pathname)) { location.replace(STORE_URL); return; }

  var root = document.documentElement;
  // Language prefix ("" for Korean, "/en", "/zh", "/ja") and currency suffix come from <html data-*>
  window.SV = {
    prefix: root.getAttribute("data-prefix") || "",
    won: root.getAttribute("data-won") || "원",
    money: function (n) { return n.toLocaleString("en-US") + window.SV.won; }
  };

  var toast = document.getElementById("toast"), timer;
  window.sveraToast = function (msg) {
    toast.textContent = msg;
    toast.classList.add("on");
    clearTimeout(timer);
    timer = setTimeout(function () { toast.classList.remove("on"); }, 3200);
  };

  if (STORE_URL) {
    document.querySelectorAll(".js-buy").forEach(function (a) {
      a.href = STORE_URL;
      a.target = "_blank";
      a.rel = "noopener";
    });
  }

  var btn = document.querySelector(".menu-btn"), drawer = document.getElementById("drawer");
  if (btn && drawer) {
    btn.addEventListener("click", function () {
      var open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!open));
      btn.setAttribute("aria-label", btn.getAttribute(open ? "data-open" : "data-close"));
      drawer.hidden = open;
    });
  }

  // Home: the header is transparent over the intro and turns solid once the page scrolls
  if (document.body.classList.contains("home")) {
    var onScroll = function () { document.body.classList.toggle("scrolled", window.scrollY > 10); };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  // Sections marked .rv fade in as they scroll into view (siblings one after another)
  var rv = document.querySelectorAll(".rv");
  if (!("IntersectionObserver" in window)) {
    rv.forEach(function (el) { el.classList.add("on"); });
  } else if (rv.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var el = e.target, i = [].indexOf.call(el.parentNode.children, el);
        el.style.transitionDelay = (Math.max(i, 0) % 4) * 90 + "ms";
        // Drop the stagger afterwards so hover effects on cards respond immediately
        setTimeout(function () { el.style.transitionDelay = ""; }, 1400);
        el.classList.add("on");
        io.unobserve(el);
      });
    }, { rootMargin: "0px 0px -8% 0px" });
    rv.forEach(function (el) { io.observe(el); });
  }
})();

/*
 * SNS 주소 설정
 * 카카오톡 채널·인스타그램이 열리면 아래 따옴표 안에 주소를 넣으세요.
 * 비워 두면 하단 아이콘을 눌렀을 때 '준비 중입니다' 안내가 뜹니다.
 * 예) kakao: "https://pf.kakao.com/_xxxxx", instagram: "https://www.instagram.com/svera.official"
 */
var SNS_URLS = { kakao: "", instagram: "" };

(function () {
  var T = {
    ko: { soon: "준비 중입니다", soonP: "곧 만나보실 수 있도록 준비하고 있습니다.", beautyP: "SVERA Beauty 라인을 준비하고 있습니다.<br>출시 소식은 공지사항으로 가장 먼저 알려 드릴게요.", close: "닫기" },
    en: { soon: "Coming soon", soonP: "We are getting this ready for you.", beautyP: "We are preparing the SVERA Beauty line.<br>Our notices will be the first to share the launch news.", close: "Close" },
    zh: { soon: "敬请期待", soonP: "我们正在准备中，敬请期待。", beautyP: "SVERA Beauty 系列正在筹备中。<br>上市消息将通过公告第一时间告知。", close: "关闭" },
    ja: { soon: "準備中です", soonP: "まもなくご利用いただけるよう準備しています。", beautyP: "SVERA Beautyラインを準備しています。<br>発売のお知らせは、お知らせページでいち早くご案内します。", close: "閉じる" }
  }[(document.documentElement.lang || "ko").slice(0, 2)] || null;
  if (!T) return;

  // ?preview=1 shows the finished SVERA Beauty page to the team; visitors get the COMING SOON screen
  var preview = /[?&]preview=1(&|$)/.test(location.search);
  if (preview) document.body.classList.remove("beauty-locked");

  document.querySelectorAll("[data-sns]").forEach(function (a) {
    var url = SNS_URLS[a.getAttribute("data-sns")];
    if (url) { a.href = url; a.target = "_blank"; a.rel = "noopener"; }
  });

  function notice(eyebrow, title, html) {
    var last = document.activeElement;
    var m = document.createElement("div");
    m.className = "sv-modal";
    m.innerHTML = '<div class="sv-modal-box" role="dialog" aria-modal="true" aria-labelledby="sv-modal-t">' +
      '<button type="button" class="sv-modal-x" aria-label="' + T.close + '">×</button>' +
      (eyebrow ? '<span class="eyebrow" lang="en">' + eyebrow + "</span>" : "") +
      '<h2 id="sv-modal-t">' + title + "</h2><p>" + html + "</p>" +
      '<button type="button" class="sv-modal-ok">' + T.close + "</button></div>";
    function onKey(e) { if (e.key === "Escape") close(); }
    function close() {
      document.removeEventListener("keydown", onKey);
      m.remove();
      if (last && last.focus) last.focus();
    }
    m.addEventListener("click", function (e) {
      if (e.target === m || e.target.closest(".sv-modal-x, .sv-modal-ok")) close();
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(m);
    m.querySelector(".sv-modal-ok").focus();
  }

  // Capture phase, so the main-screen tile animation never starts for a line that is not open yet
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a[href]") : null;
    if (!a) return;
    if (a.hasAttribute("data-sns")) {
      if (SNS_URLS[a.getAttribute("data-sns")]) return;
      e.preventDefault();
      notice("", T.soon, T.soonP);
      return;
    }
    if (!preview && a.hostname === location.hostname && /\/skincare\/?$/.test(a.pathname)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      notice("SVERA Beauty", "COMING SOON", T.beautyP);
    }
  }, true);
})();
