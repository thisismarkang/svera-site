/* 주문서: 화면만 제공하고 주문은 받지 않음. 입력값은 어디에도 전송하지 않는다.
 * Language-specific text comes from data-* attributes on the form. */
(function () {
  var PRICE = 79000;
  var form = document.getElementById("orderForm");
  var params = new URLSearchParams(location.search);
  var q = document.getElementById("q");
  q.value = Math.max(1, Math.min(99, parseInt(params.get("qty"), 10) || 1));

  if (params.get("gift") === "1") {
    var giftTitle = form.getAttribute("data-gift-title");
    document.getElementById("giftBox").hidden = false;
    document.getElementById("orderTitle").textContent = giftTitle;
    document.title = giftTitle + " | " + form.getAttribute("data-site");
  }

  function upd() {
    var n = Math.max(1, Math.min(99, parseInt(q.value, 10) || 1));
    q.value = n;
    var total = SV.money(PRICE * n);
    document.getElementById("itemPrice").textContent = total;
    document.getElementById("sumItems").textContent = total;
    document.getElementById("sumTotal").textContent = total;
    document.getElementById("payBtn").textContent = form.getAttribute("data-paybtn").replace("{price}", total);
  }
  document.getElementById("minus").onclick = function () { q.value = (parseInt(q.value, 10) || 1) - 1; upd(); };
  document.getElementById("plus").onclick = function () { q.value = (parseInt(q.value, 10) || 1) + 1; upd(); };
  q.addEventListener("change", upd);
  upd();

  var same = document.getElementById("sameAsBuyer");
  same.addEventListener("change", function () {
    if (!same.checked) return;
    document.getElementById("rcvName").value = document.getElementById("buyerName").value;
    document.getElementById("rcvTel").value = document.getElementById("buyerTel").value;
  });

  var all = document.getElementById("agreeAll"), items = document.querySelectorAll(".agree");
  all.addEventListener("change", function () { items.forEach(function (c) { c.checked = all.checked; }); });
  items.forEach(function (c) {
    c.addEventListener("change", function () { all.checked = Array.prototype.every.call(items, function (x) { return x.checked; }); });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    window.sveraToast(form.getAttribute("data-toast"));
  });
})();
