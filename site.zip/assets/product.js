(function () {
  var price = 79000, q = document.getElementById("q");
  function upd() {
    var n = Math.max(1, Math.min(99, parseInt(q.value, 10) || 1));
    q.value = n;
    document.getElementById("sub").textContent = SV.money(price * n);
    document.getElementById("tot").textContent = SV.money(price * n);
    // Carry the chosen quantity into the order sheet (unless buttons point to an external store)
    if (!STORE_URL) {
      document.getElementById("buyBtn").href = SV.prefix + "/order/?qty=" + n;
      document.getElementById("giftBtn").href = SV.prefix + "/order/?gift=1&qty=" + n;
    }
  }
  document.getElementById("minus").onclick = function () { q.value = (parseInt(q.value, 10) || 1) - 1; upd(); };
  document.getElementById("plus").onclick = function () { q.value = (parseInt(q.value, 10) || 1) + 1; upd(); };
  q.addEventListener("change", upd);

  var main = document.getElementById("mainimg");
  document.querySelectorAll(".thumbs button").forEach(function (b) {
    b.onclick = function () {
      main.src = b.dataset.src;
      document.querySelectorAll(".thumbs button").forEach(function (x) { x.setAttribute("aria-current", x === b ? "true" : "false"); });
    };
  });

  var tabs = document.querySelectorAll(".tabs a"), ids = ["detail", "review", "qna", "ship"];
  window.addEventListener("scroll", function () {
    var cur = ids[0];
    ids.forEach(function (id) { var el = document.getElementById(id); if (el && el.getBoundingClientRect().top < 160) cur = id; });
    tabs.forEach(function (a) { a.classList.toggle("on", a.getAttribute("href") === "#" + cur); });
  }, { passive: true });
})();
